package pl.pw.graterenowa.data

class Beacon {
}